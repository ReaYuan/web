
	function submit(){
		var user=$("#user").val()
		var pwd=$("#pwd").val()
		var name=$("#name").val()
		var is=$("input[name='is']:checked").val();
		if(user=="" || pwd=="" || name==""){
			alert("不能为空!")
		}else{
			if(/[1-9][0-9]{9}/.test(user)){
				$.getJSON("./index?type=insert",{"user":user,"pwd":pwd,"name":name,"is":is},function(data){
					if(data!=0){
						alert("成功")
						isempty();
					}
				});

				
			}else{
				alert("请输入正确的QQ号!")
			}
		}		
	}
	 
	function isempty(){
		$("#user").val("")
		$("#pwd").val("")
		$("#name").val("")

		$('input:radio[name=is]')[0].checked = true;
	}