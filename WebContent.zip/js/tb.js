	
window.onload=function(){
	selectCollectionPage(1,20);
}

function xiazhai(){
	$.getJSON("./xiazha",{},function(data){});
	
}

	function selectCollectionPage(page,num){
		$.getJSON("./index?type=selectAll",{"page":page,"num":num},function(data){
			list=data[0];
			count=data[1];
			$("#tb").empty();
			for(var i=0;i<list.length;i++){
				$("#tb").append("<tr><td>"+list[i].id+"</td><td>"+list[i].account+"</td><td>"+list[i].pwd+"</td><td>"+list[i].name+"</td>" +
						"<td>"+list[i].relation+"</td></tr>")
			}
			var s="<a class='a' href='javascript:selectpage(1)'>首页 </a>";
			s+="<a class='a' href='javascript:selectpageUp("+page+")'>上一页 </a>";
			if(page<=3){
				for(var i=1;i<=count && i<=5;i++){
					if(i==page){
						s+=" "+i+" ";
					}else{
						s+="<a class='a' href='javascript:selectpage("+i+")'> "+i+" </a>";
					}
				}
			}else if(page<count-1){
				for(var i=page-2;i<=page+2 && i<=count;i++){
					if(i==page){
						s+=" "+i+" ";
					}else{
						s+="<a class='a' href='javascript:selectpage("+i+")'> "+i+" </a>";
					}
				}
			}else if(page+1==count){
				for(var i=page-3;i<=count;i++){
					if(i==page){
						s+=" "+i+" ";
					}else{
						s+="<a class='a' href='javascript:selectpage("+i+")'> "+i+" </a>";
					}
				}
			}else{
				for(var i=page-4;i<=count;i++){
					if(i==page){
						s+=" "+i+" ";
					}else{
						s+="<a class='a' href='javascript:selectpage("+i+")'> "+i+" </a>";
					}
				}
			}
			s+="<a class='a' href='javascript:selectpageDown("+page+","+count+")'>下一页 </a>";	
			s+="<a class='a' href='javascript:selectCollectionPage("+count+")'> 尾页</a>";
			s+="<input el-input__inner size='2' type='text' id='page'/><button onclick='jump("+count+")' class='el-button'>查找</button>"
			$("#tb").append("<tr><td colspan='9' align='right'>"+s+"</td></tr>");
		});
	}
	
	/**
	 * 通用翻页
	 * */
	function selectpage(page){
		selectCollectionPage(page,20);
	}
	/**
	 * 上一页
	 * */
	function selectpageUp(page){
		if(page>1){
			selectCollectionPage(page-1,20);
		}else{
			alert("没有上一页了！");
		}
	}

	/**
	 * 下一页
	 * */

	function selectpageDown(page,count){
		if(page<count){
			selectCollectionPage(page+1,20);
		}else{
			alert("没有下一页了！");
		}
	}

	/**
	 * 输入页码跳转
	 * */
	function jump(count){
		var page=$("#page").val();
		if(/^\d+$/.test(page)){
			if(page>=1 && page<=count){
				selectCollectionPage(page,20);
			}else{
				alert("0<=页数<="+count);
			}
		}else{
			alert("请输入数字");
		}
		
	}